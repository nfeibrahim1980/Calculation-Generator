# Satay Calculation Generator

Cara guna:
1. Extract fail ini dan buka `index.html` dalam browser.
2. Isi kuantiti setiap jenis satay.
3. Jumlah akan dikira automatik.
4. Klik **Cetak / Simpan PDF** untuk print atau simpan.

Untuk publish ke GitHub Pages:
1. Login GitHub dan cipta repositori bernama `Calculation-Generator`
2. Upload semua fail dari ZIP ini
3. Pergi ke **Settings > Pages**
4. Pilih source: `main` branch, folder: `/ (root)`
5. Klik **Save**

Live URL akan jadi:
https://nfeibrahim1980.github.io/Calculation-Generator/
